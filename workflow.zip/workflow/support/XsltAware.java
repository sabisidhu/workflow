
package com.test.workflow.support;

import javax.xml.transform.dom.DOMSource;


public interface XsltAware {
    
    
    /**
     * Returns the DOM source object created by a previous activity. 
     * @return the DOM source object 
     */
    public  DOMSource getDomSource();
    
    /**
     * After applying an XSL transform to a DOM tree, set the resulting content
     * in a String field
     * 
     */
    public void setTransformedContent(String transformedContent); 

}
